#!/usr/bin/python
#config file containing credentials for rds mysql instance

db_username = "conner"
db_password = "(2Terpins)"
db_name = "jimcodb"
db_endpoint = "jimcodb.c6kunvjrwqvj.us-east-1.rds.amazonaws.com"
db_port = 3306
